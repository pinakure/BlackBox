from vpu        import * #deprecate import
from Vpu        import Vpu
from debug      import debug, error, panic

class HudIcon:
    game = None
    width  = 0
    height = 0
    TYPE_A = 0x00
    TYPE_B = 0x01
    TYPE_C = 0x02
    TYPE_D = 0x03
    LEVEL_0 = [ 0x00, 0x00 ]
    LEVEL_1 = [ 0x04, 0x00 ]
    LEVEL_2 = [ 0x00, 0x01 ]
    LEVEL_3 = [ 0x04, 0x01 ]
    footer = None
    gfx = {}
    weapon_type = TYPE_A
    level = 0
    timer = 0
    tileset = None
    x = 0
    y = 0
    layer_index = 2

    @staticmethod
    def initialize(game):
        HudIcon.game = game
        debug("HudIcon", "Initializing")
        HudIcon.footer = createsprite("hud_low")
        if not HudIcon.footer:
            panic("HudIcon", "Cannot load hud component 'hud_low.png'!")
        HudIcon.tileset = createsprite("hud",16)
        if not HudIcon.tileset:
            panic("HudIcon", "Cannot load hud component 'hud.png'!")
        else:
            HudIcon.gfx[HudIcon.TYPE_A] = {}
            HudIcon.gfx[HudIcon.TYPE_B] = {}
            HudIcon.gfx[HudIcon.TYPE_C] = {}
            HudIcon.gfx[HudIcon.TYPE_D] = {}
            HudIcon.gfx[HudIcon.TYPE_A][0] = createanim(16,16, HudIcon.tileset, 0, 0, 0, 0, False)
            HudIcon.gfx[HudIcon.TYPE_A][1] = createanim(16,16, HudIcon.tileset, 4, 0, 4, 0, False)
            HudIcon.gfx[HudIcon.TYPE_A][2] = createanim(16,16, HudIcon.tileset, 0, 1, 0, 1, False)
            HudIcon.gfx[HudIcon.TYPE_A][3] = createanim(16,16, HudIcon.tileset, 4, 1, 4, 1, False)
            HudIcon.gfx[HudIcon.TYPE_B][0] = createanim(16,16, HudIcon.tileset, 1, 0, 1, 0, False)
            HudIcon.gfx[HudIcon.TYPE_B][1] = createanim(16,16, HudIcon.tileset, 5, 0, 5, 0, False)
            HudIcon.gfx[HudIcon.TYPE_B][2] = createanim(16,16, HudIcon.tileset, 1, 1, 1, 1, False)
            HudIcon.gfx[HudIcon.TYPE_B][3] = createanim(16,16, HudIcon.tileset, 5, 1, 5, 1, False)
            HudIcon.gfx[HudIcon.TYPE_C][0] = createanim(16,16, HudIcon.tileset, 2, 0, 2, 0, False)
            HudIcon.gfx[HudIcon.TYPE_C][1] = createanim(16,16, HudIcon.tileset, 6, 0, 6, 0, False)
            HudIcon.gfx[HudIcon.TYPE_C][2] = createanim(16,16, HudIcon.tileset, 2, 1, 2, 1, False)
            HudIcon.gfx[HudIcon.TYPE_C][3] = createanim(16,16, HudIcon.tileset, 6, 1, 6, 1, False)
            HudIcon.gfx[HudIcon.TYPE_D][0] = createanim(16,16, HudIcon.tileset, 3, 0, 3, 0, False)
            HudIcon.gfx[HudIcon.TYPE_D][1] = createanim(16,16, HudIcon.tileset, 7, 0, 7, 0, False)
            HudIcon.gfx[HudIcon.TYPE_D][2] = createanim(16,16, HudIcon.tileset, 3, 1, 3, 1, False)
            HudIcon.gfx[HudIcon.TYPE_D][3] = createanim(16,16, HudIcon.tileset, 7, 1, 7, 1, False)
        HudIcon.weapon_type = HudIcon.TYPE_A

        Vpu.select(Vpu.overlay)
        HudIcon.width, HudIcon.height = Vpu.dimensions()

        HudIcon.x = ( HudIcon.width  >> 1 )-(16 + 8)
        HudIcon.y = ( HudIcon.height >> 1 )-(16 + 8)

    @staticmethod
    def destroy():
        if len(HudIcon.gfx) > 0:        
            for o in range(0,4):
                for i in range(0,4):
                    if HudIcon.gfx[o][i]:
                        deleteanim(HudIcon.gfx[o][i])
                        HudIcon.gfx[o][i] = None
                HudIcon.gfx[o] = {}
            HudIcon.gfx = {}
        if HudIcon.footer:
            deletesprite(HudIcon.footer)
            HudIcon.footer = None
        if HudIcon.tileset:
            deletesprite(HudIcon.tileset)
            HudIcon.tileset = None
        HudIcon.initialized = False

    @staticmethod
    def setType(weapon_type):
        HudIcon.weapon_type = weapon_type
    
    @staticmethod
    def update(delta):
        HudIcon.timer+=1
        pass

    @staticmethod
    def draw():
        #pre-clear hud buffer
        select( HudIcon.layer_index )
        fill(0,0,0,0)

        # Draw Shield energy Bar
        left = HudIcon.width >> 2
        top  = 0 # HudIcon.height >> 1
        energy_bar_width = 64
        setcolor(0,0,0, 32)
        fillrect(left+7, top + 7, energy_bar_width+4, 8)
        setcolor(0,64,64, 8)
        w = int((HudIcon.game.ship.energy / 100)* (energy_bar_width+2))
        fillrect(left+8, top + 8, w, 6)
        setcolor(0,255,255, 64)
        w = int((HudIcon.game.ship.shield.energy / 100)* energy_bar_width)
        fillrect(left+9, top + 9, w, 4)
        
        # draw powerup selection bar selection rectangle
        fx = HudIcon.width   >> 1
        fy = (HudIcon.height >> 1)-8
        o = 5
        if HudIcon.timer % 20 < 10:
            setcolor(32,32,0,8)
            if   o == 0: fillrect(fx-153,fy-4,42,8)
            elif o == 1: fillrect(fx-105,fy-4,50,8)
            elif o == 2: fillrect(fx-49,fy-4,58,8)
            elif o == 3: fillrect(fx+15,fy-4,50,8)
            elif o == 4: fillrect(fx+71,fy-4,34,8)
            elif o == 5: fillrect(fx+111,fy-4,42,8)
        
        # draw powerup selection bar selection overlay
        drawsprite(HudIcon.footer,fx,fy)
        
        # draw current weapon icon
        drawanim( 
            HudIcon.gfx[HudIcon.game.ship.weapon_type][HudIcon.game.ship.weapon_level], 
            HudIcon.x+160, HudIcon.y-8
        )        

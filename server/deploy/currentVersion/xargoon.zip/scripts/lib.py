import blackbox
import vpu

class Ship:
    def __init__(self):
        self.x = 0
        self.y = 0
        self.status = 0
        self.shooting = False
        self.sprite = vpu.createsprite("ship", 32)

    def draw():
        vpu.drawsprite(self.sprite, self.x, self.y)
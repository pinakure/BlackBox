import blackbox
import vpu

terminate = False
def main():
    while not blackbox.ctrlc():
        vpu.clear()
        vpu.update()
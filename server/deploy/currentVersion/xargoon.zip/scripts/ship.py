from vpu import *
from data.scripts.flame         import Flame
from data.scripts.projectile    import Projectile
from data.scripts.shield        import Shield
from debug                      import debug, panic, error
from random import random
import joypad

class Ship:
    TYPE_A = 0x01
    TYPE_B = 0x02
    width = 32
    height = 32
    # ------------- #
    game = None
    timer = 0
    tileset = None
    initialized = False
    shield = None

    @staticmethod
    def initialize(game):
        debug("Ship", "Initializing")
        Ship.game = game
        Ship.shield = Shield
        Ship.tileset = createsprite("ship01",10)
        Ship.initialized = True
        Ship.timer = 0        
        Shield.initialize(game)

    @staticmethod
    def destroy():
        if Ship.tileset:
            deletesprite(Ship.tileset)
            Ship.tileset = None
        Ship.initialized = False
        Shield.destroy()

    def __init__(self,x=0, y=0, ship_type=TYPE_A):
        self.x = x
        self.y = y
        self.ship_type = ship_type
        self.status = 0
        self.alive = True
        self.delta_x = 0
        self.delta_y = 0
        self.thrust = False
        self.shooting = False
        self.shoot_intent = False
        self.rapid_fire = 3
        self.energy = 100
        self.shield.energy = 100
        self.tokens = []
        self.weapon_type = int(random()*Projectile.TYPE_MAX)
        self.weapon_level = int(random()*4)
        self.anim = createanim(Ship.width, Ship.height, Ship.tileset, 0, 0, 3, 0, False, 0.125)
        self.flames =  [
            Flame(self.x, self.y + Ship.height),
            Flame(self.x, self.y + Ship.height),
        ]
        self.flames[0].rotation =  0.125
        self.flames[1].rotation = -0.125
        
    def __del__(self):
        if self.anim: deleteanim(self.anim)
        self.anim = None
        if len(self.flames)>0: 
            self.flames = []

    def move(self):
        left = 480
        right = 800-Ship.width
        top = 360
        bottom = 600-Ship.height
        self.x += self.delta_x
        self.y += self.delta_y
        self.delta_x = -.125 if self.x > right  else .125 if self.x < left else self.delta_x
        self.delta_y = -.125 if self.y > bottom else .125 if self.y < top  else self.delta_y
        self.x = right  if self.x > right   else left if self.x < left else self.x
        self.y = bottom if self.y > bottom  else top  if self.y < top  else self.y
        
    def randomize(self):
        if int(random() * 100)<50: self.west()
        else: self.east()
        if int(random() * 100)<50: self.north()
        else: self.south()        

    def update_flame(self):
        self.flames[0].x = int(self.x) - (Ship.width>>1)+6
        self.flames[0].y = int(self.y) + (Ship.height>>1)+6
        self.flames[1].x = int(self.x) + (Ship.width>>1)-6 
        self.flames[1].y = int(self.y) + (Ship.height>>1)+6
        #select flame frame depending on vertical velocity
        if self.delta_y < -1.5: 
            self.flames[0].flame_type = Flame.TYPE_D
            self.flames[1].flame_type = Flame.TYPE_D 
        elif self.delta_y < -0.75: 
            self.flames[0].flame_type = Flame.TYPE_C
            self.flames[1].flame_type = Flame.TYPE_C 
        elif self.delta_y <= 0.1: 
            self.flames[0].flame_type = Flame.TYPE_B
            self.flames[1].flame_type = Flame.TYPE_B 
        else:
            self.flames[0].flame_type = Flame.TYPE_A
            self.flames[1].flame_type = Flame.TYPE_A 
        
    def update_input(self):
        if joypad.left(): self.west()
        elif joypad.right(): self.east()
        else: self.brake_x()
            
        if joypad.up(): self.north()
        elif joypad.down(): self.south()
        else: self.brake_y()
        self.shoot_intent = True if joypad.b() else False

    def brake_y(self):
        self.delta_y *= .9

    def brake_x(self):
        self.delta_x *= .96
        
    def pickup_token(self, token_type):
        # SFX
        self.tokens.append(token_type)
        self.weapon_type = int(random()*Projectile.TYPE_MAX)
        self.weapon_level = int(random()*4)%4            

    def update(self, delta):
        if not self.alive: return
        Shield.update(delta)
        #self.randomize()
        self.update_input()

        self.move()
        self.update_flame()
        
        #divide operator to get rapid fire bonus        
        if self.shoot_intent:
            Ship.timer += 1
            if Ship.timer % (64 >> self.rapid_fire) == 0: self.shooting = True
                
        if self.shooting:
            delta_y = -1.5 + (self.delta_y) if self.delta_y < 0 else -1.5
            delta_x = .25
            Projectile.spawn(self.x+2-(Ship.width>>1), self.y-2, self.weapon_type, self.weapon_level,  delta_x , delta_y, Ship)
            Projectile.spawn(self.x+(Ship.width>>1)-2, self.y-2, self.weapon_type, self.weapon_level, -delta_x , delta_y, Ship)
            self.shooting = False
    
    def west(self):
        self.delta_x -= .125
        self.delta_x = -2.0 if self.delta_x < -2.0 else self.delta_x
        
    def east(self):
        self.delta_x += .125
        self.delta_x = 2.0 if self.delta_x > 2.0 else self.delta_x

    def north(self):
        self.delta_y -= .125
        self.delta_y = -2.0 if self.delta_y < -2.0 else self.delta_y

    def south(self):
        self.delta_y += .125
        self.delta_y = 2.0 if self.delta_y > 2.0 else self.delta_y       

    def receive_impact(self, x, y, pain=1):
        if self.shield.energy > 0:
            self.shield.sync_position( self )
            self.shield.energy -= pain
            self.shield.activate(x, y)
        else:
            self.damage(pain)

    def damage(self, pain=1):
        self.energy -= 1
        if self.energy <= 0:
            self.die()

    def die(self):
        #Spawn explosion
        for x in Ship.game.explosions:
            if x.alive: continue
            x.spawn(int(self.x)-(Ship.width>>1), int(self.y)-(Ship.height>>1))
            break
        self.alive = False
        self.energy = 0

    def draw(self):
        if not self.alive: return
        drawanim(self.anim, int(self.x), int(self.y))
        Shield.draw()
        self.flames[0].draw()
        self.flames[1].draw()
            
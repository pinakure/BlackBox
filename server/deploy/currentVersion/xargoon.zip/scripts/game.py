##############################################################################################################                                                                                                          
#                                                                                                            #
# 8b        d8         db         88888888ba     ,ad8888ba,     ,ad8888ba,      ,ad8888ba,    888b      88   #
#  Y8,    ,8P         d88b        88      "8b   d8"'    `"8b   d8"'    `"8b    d8"'    `"8b   8888b     88   #
#   `8b  d8'         d8'`8b       88      ,8P  d8'            d8'        `8b  d8'        `8b  88 `8b    88   #  
#     Y88P          d8'  `8b      88aaaaaa8P'  88             88          88  88          88  88  `8b   88   #  
#     d88b         d8YaaaaY8b     88""""88'    88      88888  88          88  88          88  88   `8b  88   #  
#   ,8P  Y8,      d8""""""""8b    88    `8b    Y8,        88  Y8,        ,8P  Y8,        ,8P  88    `8b 88   #  
#  d8'    `8b    d8'        `8b   88     `8b    Y8a.    .a88   Y8a.    .a8P    Y8a.    .a8P   88     `8888   #  
# 8P        Y8  d8'          `8b  88      `8b    `"Y88888P"     `"Y8888Y"'      `"Y8888Y"'    88      `888   #  
#                                                                                                            #
##############################################################################################################                                                                                                          
from data.scripts.ship              import Ship
from data.scripts.flame             import Flame
from data.scripts.projectile        import Projectile
from data.scripts.bigexplosion      import BigExplosion
from data.scripts.smallexplosion    import SmallExplosion
from data.scripts.token             import Token
from data.scripts.foe               import Foe
from data.scripts.bigfoe            import BigFoe
from data.scripts.hudicon           import HudIcon
from entity                         import Entity, EntityController
from random                         import random
from debug                          import debug,panic,error
from basicgame                      import BasicGame
import blackbox
import vpu
import joypad

class Game(BasicGame):
    entities = []
    tokens = []
    explosions = []
    projectiles = []
    foes = []
    ship = None
    scale = 2.0
    projectile_pool_size    = 512
    foe_pool_size           = 16
    score = 0
    timer = 0

    @staticmethod
    def prepare_background(index=0):
        vpu.select(0)
        if index==0:
            vpu.fill(8,16,32,255)
            vpu.perlin(0, 8,16,255)
        vpu.select(1)

    @staticmethod
    def setup():
        BasicGame.prepare()
        # change screen content here
        debug("Game", "Setting up")
        # prepare initial layer state
        Game.prepare_background(0)
        vpu.select(1); vpu.fill(0,0,0,0)
        vpu.select(2); vpu.fill(255,255,0,255)
        # initialize subcomponents
        debug("Game", "Initializing classes")
        HudIcon.initialize(Game)
        Token.initialize(Game)
        BigExplosion.initialize(Game)
        SmallExplosion.initialize(Game)
        Flame.initialize(Game)
        Projectile.initialize(Game)
        Ship.initialize(Game)
        Foe.initialize(Game)
        BigFoe.initialize(Game)
        debug("Game", "Initializing object pools")
        # Create token pool
        for i in range(0, 16):
            Game.randomToken()
        # Create small foe pool
        for i in range(0, Game.foe_pool_size>>1):
            Game.randomFoe(Foe)
        # Create big foe pool
        for i in range(0, Game.foe_pool_size>>1):
            Game.randomFoe(BigFoe)
        # Create big explosion pool
        for i in range(0, 32):
            Game.randomExplosion(BigExplosion)
        # Create small explosion pool
        for i in range(0, 32):
            Game.randomExplosion(SmallExplosion)
        # Create projectile pool
        for i in range(0, Game.foe_pool_size):
            Game.projectiles.append(Projectile(0,0,0,0,Foe))
        for i in range(0, Game.projectile_pool_size - Game.foe_pool_size):
            Game.projectiles.append(Projectile(0,0,0,0,Ship))
        # set video scale to 2x
        vpu.setscale(0, 2.0, 2.0)
        vpu.setscale(1, 2.0, 2.0)
        # enable rendering 
        vpu.enable(0)
        vpu.enable(1)
        vpu.enable(2)
        
        #Spawn ship
        Game.spawn()

        #Test entity system
        #-------------------------------------------------------
        ent = Entity(Game, 16,16,"Test 1")
        ent.addcontroller(EntityController.CONTROLLER_INPUT)
        ent.addcontroller(EntityController.CONTROLLER_SHOOT)
        ent.addcontroller(EntityController.CONTROLLER_MOVE)
        ent.addcontroller(EntityController.CONTROLLER_AVOID)
        ent.addcontroller(EntityController.CONTROLLER_FOLLOW)
        Game.entities.append(ent)
        #-------------------------------------------------------
        ent = Entity(Game, 16,16,"Test 2")
        ent.addcontroller(EntityController.CONTROLLER_SHOOT)
        ent.addcontroller(EntityController.CONTROLLER_MOVE)
        ent.addcontroller(EntityController.CONTROLLER_FOLLOW)
        ent.addcontroller(EntityController.CONTROLLER_AVOID)
        Game.entities.append(ent)
        #-------------------------------------------------------
        ent = Entity(Game, 16,16,"Test 3")
        ent.addcontroller(EntityController.CONTROLLER_SHOOT)
        ent.addcontroller(EntityController.CONTROLLER_MOVE)
        ent.addcontroller(EntityController.CONTROLLER_FOLLOW)
        ent.addcontroller(EntityController.CONTROLLER_AVOID)
        Game.entities.append(ent)
        #-------------------------------------------------------
        ent = Entity(Game, 16,16,"Test 4")
        ent.addcontroller(EntityController.CONTROLLER_SHOOT)
        ent.addcontroller(EntityController.CONTROLLER_MOVE)
        #ent.addcontroller(EntityController.CONTROLLER_FOLLOW)
        #ent.addcontroller(EntityController.CONTROLLER_AVOID)
        Game.entities.append(ent)
        #-------------------------------------------------------
        ent = Entity(Game, 16,16,"Test 5")
        #ent.addcontroller(EntityController.CONTROLLER_SHOOT)
        ent.addcontroller(EntityController.CONTROLLER_MOVE)
        ent.addcontroller(EntityController.CONTROLLER_FOLLOW)
        ent.addcontroller(EntityController.CONTROLLER_AVOID)
        ent.setposition(ent.x, ent.y+64)
        Game.entities.append(ent)
        #-------------------------------------------------------
        Game.entities[0].controllers[EntityController.CONTROLLER_AVOID ].set_target(Game.entities[3])
        Game.entities[1].controllers[EntityController.CONTROLLER_FOLLOW].set_target(Game.entities[3])
        Game.entities[1].controllers[EntityController.CONTROLLER_AVOID ].set_target(Game.entities[3])
        Game.entities[2].controllers[EntityController.CONTROLLER_FOLLOW].set_target(Game.entities[3])
        Game.entities[3].controllers[EntityController.CONTROLLER_SHOOT ].set_target(Game.entities[4])
        Game.entities[4].controllers[EntityController.CONTROLLER_AVOID ].set_target(Game.entities[3])
        Game.entities[4].controllers[EntityController.CONTROLLER_FOLLOW].set_target(Game.entities[3])
        sprite = vpu.createsprite('foe0')
        subspr = vpu.subsprite(sprite, 0,  0, 16, 16) 
        Game.entities[0].setsprite(subspr)
        Game.entities[1].setsprite(subspr)
        Game.entities[2].setsprite(subspr)
        Game.entities[3].setsprite(subspr)
        Game.entities[4].setsprite(subspr)
        BasicGame.autoredraw = False
        
    @staticmethod
    def randomExplosion(baseclass):
        x = int(Game.width>>2)  + int(random()*(Game.width>>1))-16
        y = int(Game.height>>2) + int(random()*(Game.height>>1))-16
        s = baseclass(x,y)
        s.time += int(random()*30)
        s.alive = False
        Game.explosions.append(s)
    
    @staticmethod
    def randomFoe(baseclass):
        x = int(random() * Game.width  ) - 16
        y = int(random() * Game.height ) - 16
        foe_type = int(random()*(Foe.TYPE_MAX))
        s = baseclass(x,y,foe_type)
        Game.foes.append(s)
    
    @staticmethod
    def randomToken():
        x = int(Game.width  >> 2) + int(random()*(Game.width  >> 1))-16
        y = int(Game.height >> 2) + int(random()*(Game.height >> 1))-16
        token_type = int(random()*(Token.TYPE_MAX))
        t = Token(x, y, token_type)
        t.alive = False
        Game.tokens.append(t)

    @staticmethod
    def spawn():
        w = int(Game.width>>1)-16
        h = int(Game.height>>1)
        Game.ship = Ship(w, h, Ship.TYPE_A)

    @staticmethod
    def destroy():
        Game.entities = []
        Game.tokens = []
        Game.explosions = []
        Game.projectiles = []
        Game.foes = []
        Game.ship = None

        Token.destroy()
        HudIcon.destroy()
        BigExplosion.destroy()
        SmallExplosion.destroy()
        Projectile.destroy()
        Flame.destroy()
        Ship.destroy()
        Foe.destroy()
        BigFoe.destroy()
        #BasicGame.destroy()
        
    @staticmethod
    def loop():
        delta = 1.0
        Game.timer = 0
        vpu.setscale(1,Game.scale, Game.scale)
        while Game.running:
            Game.timer+=1        
            Game.draw()
            Game.update(delta)            
            
    @staticmethod
    def animate():
        for i in range(0, Token.TYPE_MAX):
            vpu.updateanim(Token.gfx[i])
        for i in range(0, 4):
            vpu.updateanim(Flame.gfx[i])
        vpu.updateanim(Game.ship.anim)
        
    @staticmethod
    def update(delta):
        HudIcon.update(delta)
        for token in Game.tokens:
            if token.alive: token.update(delta)
        for explosion in Game.explosions:
            if explosion.alive: explosion.update(delta)
        for foe in Game.foes:
            if foe.alive: foe.update(delta)
            else: foe.spawn()
        for projectile in Game.projectiles:
            if projectile.alive: projectile.update(delta)
        Game.ship.update(delta)
        # required BasicGame stuff
        BasicGame.update(delta)
        
    @staticmethod
    def draw():
        Game.animate()
        # Draw hud (drawn on self-managed layer)
        HudIcon.draw()
        # pre-clean foreground layer
        vpu.select(1)
        vpu.fill(0,0,0,0)
        for token in Game.tokens:            
            if token.alive: token.draw()
        for foe in Game.foes:            
            if foe.alive: foe.draw()
        vpu.select(1)
        vpu.setrotation(1, 0)
        
        for explosion in Game.explosions:            
            if explosion.alive:explosion.draw()
        for projectile in Game.projectiles:
            projectile.draw()
        # Draw Ship (drawn on foreground layer)       
        Game.ship.draw()
        # raster screen and update input
        
        vpu.update()
